/*
 * Summary: Removed legacy symbols for an outdated FTP client
 *
 * Copy: See Copyright for the status of this software.
 *
 * Author: Daniel Veillard
 */

#ifndef __NANO_FTP_H__
#define __NANO_FTP_H__
#endif /* __NANO_FTP_H__ */
