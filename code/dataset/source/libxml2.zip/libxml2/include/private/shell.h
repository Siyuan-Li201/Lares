#ifndef XML_SHELL_H_PRIVATE__
#define XML_SHELL_H_PRIVATE__

void
xmllintShell(xmlDocPtr doc, const char *filename, FILE *output);

#endif /* XML_SHELL_H_PRIVATE__ */
